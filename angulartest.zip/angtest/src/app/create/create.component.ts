import { Component, OnInit } from '@angular/core';
import{Test} from './../Test';
import{TestserviceService} from './../testservice.service';
import{Router} from '@angular/router';
import{NgForm} from '@angular/forms'

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
emp= new Test();
  constructor(private tl:TestserviceService, private route:Router) { }

  ngOnInit() {
  }
  saveTest():void{
    this.tl.save(this.emp);
    console.log(this.emp)
      this.route.navigate(['list']);
    }
    updateTest():void{
      this.tl.save(this.emp);
        this.route.navigate(['list']);
      }
}
