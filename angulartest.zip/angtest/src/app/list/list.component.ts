import { Component, OnInit } from '@angular/core';
import{Test} from './../Test';
import{TestserviceService} from './../testservice.service';
import{Router} from '@angular/router';
import{HttpClient} from '@angular/common/http'

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  emp:Test;
  updatediv=false;
  indexposition:number;
emplist :Test[];

  constructor(private tl:TestserviceService,private route :Router) {
    this.emplist=this.tl.gettests();
   }

  ngOnInit() {
  }
  edit(index:number)
  {   
    console.log("Index "+index);
     this.updatediv=true; 
     this.emp=this.emplist[index];
    this.tl.update(this.emp,this.indexposition);  
   }
  deleteTest(index:number)
  {
    this.tl.delete(index);
   }
}
