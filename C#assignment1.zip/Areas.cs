﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class Areas
    {
        public float length, breadth, side, height, tribase, radius;

        public void Square()
        {
            Console.WriteLine("Enter the side of the square : ");
            side = int.Parse(Console.ReadLine());
            Console.WriteLine("Area of the square is {0}", side * side);
            Console.ReadLine();
        }
        public void Rectangle()
        {
            Console.WriteLine("Enter the length of the rectangle : ");
            length = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the breadth of the rectangle : ");
            breadth = int.Parse(Console.ReadLine());
            Console.WriteLine("Area of the rectangle is {0}", length * breadth);
            Console.ReadLine();
        }
        public void Triangle()
        {
            Console.WriteLine("Enter the base of the triangle : ");
            tribase = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the height of the triangle : ");
            height = int.Parse(Console.ReadLine());
            Console.WriteLine("Area of the triangle is : {0}", (tribase * height) / 2);
            Console.ReadLine();
        }
        public void Circle()
        {
            Console.WriteLine("Enter the radius of the circle");
            radius = int.Parse(Console.ReadLine());
            Console.WriteLine("Area of the circle is {0}", 3.14 * radius * radius);
            Console.ReadLine();
        }
    }
}
