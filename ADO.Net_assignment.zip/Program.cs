﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee_DAL;
using System.Data.SqlClient;

namespace ADO_Demos
{
    class Program
    {
        Class1 employee;
        static void Main(string[] args)
        {
            Program p = new Program();
            p.readempdetails();
            //p.getEmployeeDetail();
            //p.updateempdetails();
            //p.deleteempdetails();
            Console.ReadLine();
        }
        public void getEmployeeDetail()
        {
            Console.WriteLine("enter id,name,gender,location and salary");
            employee = new Class1();
            employee.Id = int.Parse(Console.ReadLine());
            employee.Name = Console.ReadLine();
            employee.Gender = Console.ReadLine();
            employee.Location = Console.ReadLine();
            employee.Salary = int.Parse(Console.ReadLine());
            int count = employee.InsertEmployee(employee);
            if(count>0)
            Console.WriteLine("record inserted successfully");
            else
                Console.WriteLine("Somethig went wrong..!!");
        }
        public void updateempdetails()
        {
            employee = new Class1();
            Console.WriteLine("enter id to update");
            employee.Id = int.Parse(Console.ReadLine());
            Console.WriteLine("enter name,gender,location and salary");
            employee.Name = Console.ReadLine();
            employee.Gender = Console.ReadLine();
            employee.Location = Console.ReadLine();
            employee.Salary = int.Parse(Console.ReadLine());
            int row=employee.UpdateEmployee(employee);

            if (row > 0)
                Console.WriteLine("record inserted successfully");
            else
                Console.WriteLine("Somethig went wrong..!!");
        }
        public void deleteempdetails()
        {
            employee = new Class1();
            Console.WriteLine("enter id to delete");
            employee.Id = int.Parse(Console.ReadLine());
            int rows = employee.DeleteEmployee(employee);

            if (rows > 0)
                Console.WriteLine("record deleted successfully");
            else
                Console.WriteLine("Something went wrong..!!");
        }
        public void readempdetails()
        {
            employee = new Class1();
            employee.ReadEmployee(employee);

        }
    }
}
