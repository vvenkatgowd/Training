﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Employee_DAL
{
    public class Class1
    {
        private int id, salary;
        private string name, gender, location;
        public int Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public string Gender { get => gender; set => gender = value; }
        public int Salary { get => salary; set => salary = value; }
        public string Location { get => location; set => location = value; }
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        string constr = "data source=IN5CG9214X5G;database=ADO_Demo;integrated security=true;";
        public int InsertEmployee(Class1 employee)
        {
            cmd.Connection = con;
            con.ConnectionString = constr;
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = "sp_InsertNewEmployee";
            cmd.Parameters.AddWithValue("id", employee.Id);
            cmd.Parameters.AddWithValue("name", employee.Name);
            cmd.Parameters.AddWithValue("gender", employee.Gender);
            cmd.Parameters.AddWithValue("location", employee.Location);
            cmd.Parameters.AddWithValue("salary", employee.Salary);
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            return rowcount;
        }
        public int UpdateEmployee(Class1 employee)
        {
            cmd.Connection = con;
            con.ConnectionString = constr;
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = "sp_UpdateEmployee";
            cmd.Parameters.AddWithValue("id", employee.Id);
            cmd.Parameters.AddWithValue("name", employee.Name);
            cmd.Parameters.AddWithValue("gender", employee.Gender);
            cmd.Parameters.AddWithValue("location", employee.Location);
            cmd.Parameters.AddWithValue("salary", employee.Salary);
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            return rowcount;
        }
        public int DeleteEmployee(Class1 employee)
        {
            cmd.Connection = con;
            con.ConnectionString = constr;
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = "sp_DeleteEmployeeById";
            cmd.Parameters.AddWithValue("id", employee.Id);
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            return rowcount;
        }
        public void ReadEmployee(Class1 employee)
        {
            cmd.Connection = con;
            con.ConnectionString = constr;         
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = "RetrieveAllEmployees";
            con.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                Console.WriteLine($" {rdr[0]} \t {rdr[1]} \t {rdr["Gender"]} \t {rdr["Location"]}\t {rdr["Salary"]}");
            }
            con.Close();
            
        }
        }
}
