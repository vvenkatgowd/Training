import { Injectable } from '@angular/core';
import{Test} from './test'

@Injectable({
  providedIn: 'root'
})
export class TestserviceService {
  private emplist:Test[]=[
    {Department:1,Name:'Engineering',GroupName:'Research and Development',ModifiedDate:new Date('2002-06-01')},
    {Department:2,Name:'Tool Design',GroupName:'Research and Development',ModifiedDate:new Date('2002-06-01')},
    {Department:3,Name:'Sales',GroupName:'Sales and Marketing',ModifiedDate:new Date('2002-06-01')},
    {Department:4,Name:'Marketing',GroupName:'Research and Development',ModifiedDate:new Date('2002-06-01')},
  ];

  constructor() { }
  gettests(){
    return this.emplist;
      }
    
      save(emp:Test)
      {
        this.emplist.push(emp);
      }
      update(test:Test,index:number)
      {
         this.emplist[index]=test;
          }
      delete(index :number)
      {
        this.emplist.splice(index,1);
      }
    }
