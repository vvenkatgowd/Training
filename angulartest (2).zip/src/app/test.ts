export class Test{
    Department :number;
    Name:string;
    GroupName:string;
    ModifiedDate:Date
}