import { Component, OnInit, Input } from '@angular/core';
import{Test} from './../Test';
import{TestserviceService} from './../testservice.service';
import{Router} from '@angular/router'

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  emp:Test;
  updatedindex:number;
@Input()

  rowindex:number;

  constructor(private tl:TestserviceService,private route:Router) { }

  ngOnInit() {
  }
  updateTest(index:number)
  {
    
  }
}
